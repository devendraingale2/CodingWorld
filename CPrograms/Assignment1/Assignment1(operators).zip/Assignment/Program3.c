
#include<stdio.h>

void main(){

int x=10,y=20;

//Here x is smaller than y.Lets prove x and y is also less than x.


int z=x & y;
printf("%d&%d=%d",x,y,z);

}
