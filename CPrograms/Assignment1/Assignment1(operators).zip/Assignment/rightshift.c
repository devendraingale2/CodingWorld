
#include<stdio.h>

void main(){

printf("1>>2=%d\n",1>>2);
printf("3>>3=%d\n",3>>5);
printf("5>>3=%d\n",5>>3);



}
