#include<stdio.h>

void main(){

	int a;
	char c;
	float f;
	
	printf("\nEnter Integer Value:");
	scanf("%d",&a);

	printf("\nEnter Char Value:");
        scanf(" %c",&c);

	printf("Enter FLoat Value:");
        scanf("%f",&f);
	
	printf("\nInteger Value:%d",a);
	printf("\nChar Value:%c",c);
        printf("\nFloat Value:%f",f);


}
