

#include<stdio.h>

void main(){

	float num1,num2,avg;
	printf("Enter num1:");scanf("%f",&num1);
	printf("\nEnter num2:");scanf("%f",&num2);
	
	avg=(num1+num2)/2;
	printf("\nAverage of Numbers is:%f\n",avg);


}
