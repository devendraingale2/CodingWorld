
#include<stdio.h>

void main(){

	for(int i=1;i<=128;i++){
	
		printf("%d=%c\n",i,i);
			
	}

}
