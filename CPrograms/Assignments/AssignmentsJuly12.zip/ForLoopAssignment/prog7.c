#include<stdio.h>

void main(){
	
	for(int i=1;i<=10;i++){
		
		printf("6*%d=%d\n",i,6*i);
	}

}
