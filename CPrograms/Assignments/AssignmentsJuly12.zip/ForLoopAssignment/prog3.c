
#include<stdio.h>

void main(){
	
	for(int i=50;i<=70;i++){
		
		if(i%2==0){
			printf("%d\n",i);
		}
	}


}
