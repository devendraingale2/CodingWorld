
#include<stdio.h>

void main(){

	int a=65;
	for(int i=1;i<=65;i++){
	
		if(a%i==0){
			printf("%d\n",i);
		}
		
	}


}
