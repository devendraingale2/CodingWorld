
#include<stdio.h>
void main(){

	int a,b=1;
	printf("Enter a Number:");
	scanf("%d",&a);
	for(int i=1;i<=10;i++){
		
		printf("%d*%d=%d\n",a,i,a*i);
	
	}


}
