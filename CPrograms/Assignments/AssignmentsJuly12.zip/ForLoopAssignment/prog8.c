#include<stdio.h>

void main(){
	
	char y='y',j='j';
	for(int i=y;i>=j;i--){
	
		printf("%c\n",i);
	}

}
