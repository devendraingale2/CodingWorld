
#include<stdio.h>

void main(){
	
	for(int i=30;i>=15;i--){
	
		printf("%d\n",i);
		i--;
	}


}
