
#include<stdio.h>

void main(){

	int n,i;
	i=0;
	printf("Enter a Number:");
	scanf("%d",&n);

	while(n>i){
	
	printf("%d",n);
	n--;
	}

}
