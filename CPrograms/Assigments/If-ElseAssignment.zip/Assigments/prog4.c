#include<stdio.h>
void main(){

	float x=5.2, y=10.5;
	if(x == 5.2){
		printf("x : %f\n",x);
	}
	if(y == 10.5);{
		printf("y : %f\n",y);
	}

}

//here variable is float and it needs %f to print not %d
//One closing bracket was missing in code.
//Here first if is true so it is executed.
//second if has semicolon so code below it is a block code andit is executed.
