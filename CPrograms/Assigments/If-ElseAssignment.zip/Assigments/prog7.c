#include<stdio.h>

void main(){

	int weight=50;
	if(weight<50 && weight >30){
	printf("You are under weight");
	}
	if(weight>=50 && weight <= 70){
	printf("you are well maintained");
	}
	if(weight > 70);{
	printf("you are overweight you have to work hard\n");
	}
}

//first if will not be executed
//Code is correct and it will execute properly
