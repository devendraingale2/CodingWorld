#include<stdio.h>
void main(){

	int a;
	printf("Enter a Number:");
	scanf("%d",&a);
	if(a>=25 || a<=50){
		printf("%d is between 25-50.",a);
	}


}
