#include<stdio.h>
void main(){

int num=20;
if(num >20){
printf(" num is greater than 20");
}
printf(" num : %d \n", num);
}

//Here number is itself 20 so it cant be greater than 20.Hence if statement code is not executed.
