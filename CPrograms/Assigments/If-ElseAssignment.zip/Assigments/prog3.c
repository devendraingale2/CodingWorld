#include<stdio.h>
void main(){
	int ilc=15, olc= 25;
	if(olc >ilc){
		printf("olc : %d\n",olc);
	}

	if(ilc<olc);{
	printf("ilc : %d\n",ilc);
	}
	printf("olc : %d\n",olc);
	printf("ilc : %d\n",ilc);

}


//Here due to semicolon to if ,there is no opening to if and hence the rest code is executed.
