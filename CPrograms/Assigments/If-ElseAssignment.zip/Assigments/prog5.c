#include<stdio.h>
void main(){

	bool val=false, var=true;
	if(val);{
		printf("true");
	}
	if(var){
		printf("false");
	}
}
