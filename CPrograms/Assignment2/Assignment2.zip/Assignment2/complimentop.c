#include<stdio.h>

void main(){

int x=35;
printf("~%d=%d\n",x,~x);

//2
x=12;
printf("~%d=%d\n",x,~x);

//3
x=78;
printf("~%d=%d\n",x,~x);



}
