#include<stdio.h>

void main(){

//1
int x=7,y=8;
printf("%d^%d=%d\n",x,y,x^y);

//2
x=23,y=23;
printf("%d^%d=%d\n",x,y,x^y);

//3
x=-8,y=4;
printf("%d^%d=%d\n",x,y,x^y);

//4
x=-3,y=-3;
printf("%d^%d=%d\n",x,y,x^y);



}
