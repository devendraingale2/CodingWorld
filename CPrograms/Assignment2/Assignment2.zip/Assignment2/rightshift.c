
#include<stdio.h>
void main(){


//1	
int x=21;
printf("%d>>2=%d\n",x,x>>2);


//2
x=17;
printf("%d<<3=%d\n",x,x<<2);



//3
x=98;
printf("%d>>2=%d\n",x,x>>2);

//4
x=38;
printf("%d<<3=%d\n",x,x<<3);
}
